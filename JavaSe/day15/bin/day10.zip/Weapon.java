abstract class Weapon implements Assaultable,Mobile{
	public void attack(){};
	public void move(){};

}