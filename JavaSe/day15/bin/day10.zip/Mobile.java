interface Mobile{
	void move();
}