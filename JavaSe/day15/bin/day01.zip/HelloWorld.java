import java.util.Scanner;
public class HelloWorld{
		public static void main(String args[]){
			Scanner in = new Scanner(System.in);
			System.out.println("������Hello xxxxx");
			String s = in.next();
			System.out.println(s);
		}
	}
	